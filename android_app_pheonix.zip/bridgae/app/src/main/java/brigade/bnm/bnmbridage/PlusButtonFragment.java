package brigade.bnm.bnmbridage;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

/**
 * Created by jinyeong on 2018-09-28.
 */

public class PlusButtonFragment extends Fragment {

    public static PlusButtonFragment newInstance() {
        return new PlusButtonFragment();
    }
    private WebView view;
    ProgressBar progressBar;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_web_view, container, false);


        progressBar = (ProgressBar)v.findViewById(R.id.progressBar);

        view = (WebView) v.findViewById(R.id.webview);
        view.setWebViewClient(new WebViewClientDemo());
        view.setWebChromeClient(new WebChromeClientDemo());
        view.getSettings().setJavaScriptEnabled(true);
        view.loadUrl("http://bnmbrigade.surge.sh");
        return v;
    }
    private class WebViewClientDemo extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.GONE);
//            progressBar.setProgress(100);
        }
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            progressBar.setVisibility(View.VISIBLE);
//            progressBar.setProgress(0);
        }
    }
    private class WebChromeClientDemo extends WebChromeClient {
        public void onProgressChanged(WebView view, int progress) {
//            progressBar.setProgress(progress);
        }
    }
}


