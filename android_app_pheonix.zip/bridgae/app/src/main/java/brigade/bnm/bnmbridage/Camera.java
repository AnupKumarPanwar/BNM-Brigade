package brigade.bnm.bnmbridage;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.androidfung.geoip.IpApiService;
import com.androidfung.geoip.ServicesManager;
import com.androidfung.geoip.model.GeoIpResponseModel;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.UploadProgressListener;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import id.zelory.compressor.Compressor;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import pl.tajchert.nammu.Nammu;
import retrofit2.Call;
import retrofit2.Callback;

public class Camera extends AppCompatActivity {
    double longitude;
    double latitude;
    Location location;
    String path;
    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidNetworking.initialize(getApplicationContext());
        setContentView(R.layout.activity_camera);
        EasyImage.openCamera(this, 0);
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        IpApiService ipApiService = ServicesManager.getGeoIpService();
        ipApiService.getGeoIp().enqueue(new Callback<GeoIpResponseModel>() {
            @Override
            public void onResponse(Call<GeoIpResponseModel> call, retrofit2.Response<GeoIpResponseModel> response) {
                String country = response.body().getCountry();
                String city = response.body().getCity();
                String countryCode = response.body().getCountryCode();
                latitude = response.body().getLatitude();
                 longitude = response.body().getLongitude();
                String region = response.body().getRegion();
                String timezone = response.body().getTimezone();
                String isp = response.body().getIsp();
            }

            @Override
            public void onFailure(Call<GeoIpResponseModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        final ProgressDialog progress = new ProgressDialog(Camera.this);
        progress.setTitle("Uploading");
        progress.setMessage("Wait while uploading...");
        progress.setCancelable(false);
        findViewById(R.id.report).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File compressedImageFile = new File(path);
                try {
                     compressedImageFile = new Compressor(getBaseContext()).compressToFile(new File(path));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                AndroidNetworking.upload("http://46c38082.ngrok.io/upload")
                        .addMultipartFile("image", compressedImageFile)
                        .addMultipartParameter("report_text", "adsad")
                        .addMultipartParameter("lat", latitude + "")
                        .addMultipartParameter("lng", longitude + "")
                        .setTag("uploadTest")
                        .setPriority(Priority.HIGH)
                        .build()
                        .setUploadProgressListener(new UploadProgressListener() {
                            @Override
                            public void onProgress(long bytesUploaded, long totalBytes) {
                                // do anything with progress
                               // disable dismiss by tapping outside of the dialog
                                progress.show();
// To dismiss the dialog
                            }
                        })
                        .getAsJSONObject(new JSONObjectRequestListener() {
                            @Override
                            public void onResponse(JSONObject response) {
                                // do anything with response
                                progress.dismiss();

                            }

                            @Override
                            public void onError(ANError error) {
                                // handle error
                            }
                        });
            }

        });
    }
    public Bitmap getBitmap(String path) {
        try {
            Bitmap bitmap=null;
            File f= new File(path);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;

            bitmap = BitmapFactory.decodeStream(new FileInputStream(f), null, options);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePickerError(Exception e, EasyImage.ImageSource source, int type) {
                //Some error handling
                e.printStackTrace();
            }

            @Override
            public void onImagePicked(File imageFile, EasyImage.ImageSource source, int type) {
                Log.e("asd",imageFile.getAbsolutePath());
                path = imageFile.getAbsolutePath();
                ImageView photo = findViewById(R.id.photo);
//                Picasso.get().load(imageFile).into(getBitmap(path));

                TextView lat = findViewById(R.id.lat);
                lat.setText("Latitude : "+ latitude+"");

                TextView lon = findViewById(R.id.lon);
                lon.setText("Longitude : "+ longitude+"");
                photo.setImageBitmap(getBitmap(path));
            }

            @Override
            public void onCanceled(EasyImage.ImageSource source, int type) {
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Nammu.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }



}

